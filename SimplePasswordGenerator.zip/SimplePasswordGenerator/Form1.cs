﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        int safePasswordDirective = Properties.Settings.Default.safePasswordDirective;
        public Form1()
        {
            InitializeComponent();
            numericUpDown1.Value = safePasswordDirective;
        }

        
        
        private void generatePasswordButton_Click(object sender, EventArgs e)
        {
            generatedPasswordTextBox.Clear();

            Password formPassword = new Password(Convert.ToInt32(numericUpDown1.Value), useAlphabetCheckBox.Checked, useSpecialCharactersCheckBox.Checked, dontRepeatCharactersCheckBox.Checked);

            generatedPasswordTextBox.Text = formPassword.result;
            previousPasswordscomboBox.Items.Add(generatedPasswordTextBox.Text);
            previousPasswordscomboBox.SelectedItem = previousPasswordscomboBox.Items[previousPasswordscomboBox.Items.Count - 1]; 
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            

            if (numericUpDown1.Value < safePasswordDirective)
            {

                MessageBox.Show($"You're about to use less characters than the minimum set in the directive = {safePasswordDirective}", "Increase the number of characters", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }

        }

        private void copySelectedPreviousPassword_Click(object sender, EventArgs e) 
        {
            if (previousPasswordscomboBox.Items.Count > 0)
            {
                Clipboard.SetText(previousPasswordscomboBox.SelectedItem.ToString());
            }
            else 
            {
                MessageBox.Show("There's nothing to copy","Create a password first", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }

        private void clearListButton_Click(object sender, EventArgs e)
        {
            previousPasswordscomboBox.Items.Clear();
            MessageBox.Show("The list has been cleared succesfully","Done",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void clearListButton_MouseHover(object sender, EventArgs e)
        {

        }

        private void generatePasswordButton_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(generatePasswordButton, "Make a password with the parameters below");
        }

        private void dontRepeatCharactersCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            int count = 9;
            if (dontRepeatCharactersCheckBox.Checked == true)
            {
                if (useAlphabetCheckBox.Checked)
                {
                    count = +52;
                }
                if (useSpecialCharactersCheckBox.Checked)
                {
                    count += 30;
                }

                numericUpDown1.Value = count;
                numericUpDown1.Maximum = count;
                useSpecialCharactersCheckBox.Enabled = false;
                useAlphabetCheckBox.Enabled = false;
            }
            else 
            {
               
                numericUpDown1.Maximum = 100;
                useSpecialCharactersCheckBox.Enabled = true;
                useAlphabetCheckBox.Enabled = true;
            }


        }

        private void previousPasswordscomboBox_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(previousPasswordscomboBox, $"You have stored {previousPasswordscomboBox.Items.Count} passwords so far");
        }

        private void copySelectedPreviousPassword_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(copySelectedPreviousPassword, $"click to copy the selected password to the clipboard");
        }

        private void saveToFileButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog passwordTxtSaveDialog = new SaveFileDialog();
            passwordTxtSaveDialog.Filter = "Text files (*.txt) | *.txt ";

            if (passwordTxtSaveDialog.ShowDialog() == DialogResult.OK) 
            {
                if ((passwordTxtSaveDialog.FileName) != null) 
                {
                    string savePath = passwordTxtSaveDialog.FileName;
                    StreamWriter outputfileStream = new StreamWriter(savePath);
                    outputfileStream.WriteLine("----- Generated List Of Passwords / ------\n\n");
                    outputfileStream.WriteLine($" ---- For a total of {previousPasswordscomboBox.Items.Count} passwords ---- \n");

                    int count = 0;
                    foreach (string password in previousPasswordscomboBox.Items) 
                    {
                        count++;
                        outputfileStream.WriteLine($" {count}.   {password}   ");
                    }

                    outputfileStream.WriteLine("\n\n-----Password Generator -----\n Version 1.0 / Jafet Valencia / 2021 ");
                    outputfileStream.Close();
                }
                
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/Jafetsalo/PasswordMakerRepo");
        }


    }
}

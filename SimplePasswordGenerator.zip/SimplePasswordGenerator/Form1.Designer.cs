﻿
namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.generatePasswordButton = new System.Windows.Forms.Button();
            this.generatedPasswordTextBox = new System.Windows.Forms.RichTextBox();
            this.previousPasswordscomboBox = new System.Windows.Forms.ComboBox();
            this.copySelectedPreviousPassword = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.useAlphabetCheckBox = new System.Windows.Forms.CheckBox();
            this.useSpecialCharactersCheckBox = new System.Windows.Forms.CheckBox();
            this.saveToFileButton = new System.Windows.Forms.Button();
            this.clearListButton = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dontRepeatCharactersCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // generatePasswordButton
            // 
            this.generatePasswordButton.Location = new System.Drawing.Point(67, 97);
            this.generatePasswordButton.Name = "generatePasswordButton";
            this.generatePasswordButton.Size = new System.Drawing.Size(155, 42);
            this.generatePasswordButton.TabIndex = 0;
            this.generatePasswordButton.Text = "Generate Password";
            this.generatePasswordButton.UseVisualStyleBackColor = true;
            this.generatePasswordButton.Click += new System.EventHandler(this.generatePasswordButton_Click);
            this.generatePasswordButton.MouseHover += new System.EventHandler(this.generatePasswordButton_MouseHover);
            // 
            // generatedPasswordTextBox
            // 
            this.generatedPasswordTextBox.Location = new System.Drawing.Point(309, 97);
            this.generatedPasswordTextBox.MaxLength = 20000;
            this.generatedPasswordTextBox.Name = "generatedPasswordTextBox";
            this.generatedPasswordTextBox.Size = new System.Drawing.Size(258, 42);
            this.generatedPasswordTextBox.TabIndex = 1;
            this.generatedPasswordTextBox.Text = "";
            // 
            // previousPasswordscomboBox
            // 
            this.previousPasswordscomboBox.FormattingEnabled = true;
            this.previousPasswordscomboBox.Location = new System.Drawing.Point(22, 33);
            this.previousPasswordscomboBox.Name = "previousPasswordscomboBox";
            this.previousPasswordscomboBox.Size = new System.Drawing.Size(296, 21);
            this.previousPasswordscomboBox.TabIndex = 2;
            this.previousPasswordscomboBox.MouseHover += new System.EventHandler(this.previousPasswordscomboBox_MouseHover);
            // 
            // copySelectedPreviousPassword
            // 
            this.copySelectedPreviousPassword.Location = new System.Drawing.Point(22, 78);
            this.copySelectedPreviousPassword.Name = "copySelectedPreviousPassword";
            this.copySelectedPreviousPassword.Size = new System.Drawing.Size(149, 23);
            this.copySelectedPreviousPassword.TabIndex = 3;
            this.copySelectedPreviousPassword.Text = "Copy Selected Password";
            this.copySelectedPreviousPassword.UseVisualStyleBackColor = true;
            this.copySelectedPreviousPassword.Click += new System.EventHandler(this.copySelectedPreviousPassword_Click);
            this.copySelectedPreviousPassword.MouseHover += new System.EventHandler(this.copySelectedPreviousPassword_MouseHover);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(205, 206);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.MinimumSize = new System.Drawing.Size(1, 0);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 20);
            this.numericUpDown1.TabIndex = 4;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Number of characters";
            // 
            // useAlphabetCheckBox
            // 
            this.useAlphabetCheckBox.AutoSize = true;
            this.useAlphabetCheckBox.Location = new System.Drawing.Point(48, 246);
            this.useAlphabetCheckBox.Name = "useAlphabetCheckBox";
            this.useAlphabetCheckBox.Size = new System.Drawing.Size(168, 17);
            this.useAlphabetCheckBox.TabIndex = 6;
            this.useAlphabetCheckBox.Text = "Include Alphabetic Characters";
            this.useAlphabetCheckBox.UseVisualStyleBackColor = true;
            // 
            // useSpecialCharactersCheckBox
            // 
            this.useSpecialCharactersCheckBox.AutoSize = true;
            this.useSpecialCharactersCheckBox.Location = new System.Drawing.Point(48, 269);
            this.useSpecialCharactersCheckBox.Name = "useSpecialCharactersCheckBox";
            this.useSpecialCharactersCheckBox.Size = new System.Drawing.Size(153, 17);
            this.useSpecialCharactersCheckBox.TabIndex = 7;
            this.useSpecialCharactersCheckBox.Text = "Include Special Characters";
            this.useSpecialCharactersCheckBox.UseVisualStyleBackColor = true;
            // 
            // saveToFileButton
            // 
            this.saveToFileButton.Location = new System.Drawing.Point(177, 78);
            this.saveToFileButton.Name = "saveToFileButton";
            this.saveToFileButton.Size = new System.Drawing.Size(150, 23);
            this.saveToFileButton.TabIndex = 8;
            this.saveToFileButton.Text = "Save to text file";
            this.saveToFileButton.UseVisualStyleBackColor = true;
            this.saveToFileButton.Click += new System.EventHandler(this.saveToFileButton_Click);
            // 
            // clearListButton
            // 
            this.clearListButton.Location = new System.Drawing.Point(324, 35);
            this.clearListButton.Name = "clearListButton";
            this.clearListButton.Size = new System.Drawing.Size(103, 19);
            this.clearListButton.TabIndex = 9;
            this.clearListButton.Text = "Clear List";
            this.toolTip1.SetToolTip(this.clearListButton, "Clears the password data ");
            this.clearListButton.UseVisualStyleBackColor = true;
            this.clearListButton.Click += new System.EventHandler(this.clearListButton_Click);
            this.clearListButton.MouseHover += new System.EventHandler(this.clearListButton_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(605, 148);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(137, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Link to repository");
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // dontRepeatCharactersCheckBox
            // 
            this.dontRepeatCharactersCheckBox.AutoSize = true;
            this.dontRepeatCharactersCheckBox.Location = new System.Drawing.Point(48, 292);
            this.dontRepeatCharactersCheckBox.Name = "dontRepeatCharactersCheckBox";
            this.dontRepeatCharactersCheckBox.Size = new System.Drawing.Size(150, 17);
            this.dontRepeatCharactersCheckBox.TabIndex = 10;
            this.dontRepeatCharactersCheckBox.Text = "Do not Repeat Characters";
            this.dontRepeatCharactersCheckBox.UseVisualStyleBackColor = true;
            this.dontRepeatCharactersCheckBox.CheckedChanged += new System.EventHandler(this.dontRepeatCharactersCheckBox_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.clearListButton);
            this.groupBox1.Controls.Add(this.saveToFileButton);
            this.groupBox1.Controls.Add(this.copySelectedPreviousPassword);
            this.groupBox1.Controls.Add(this.previousPasswordscomboBox);
            this.groupBox1.Location = new System.Drawing.Point(281, 269);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(461, 157);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Saved Passwords";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dontRepeatCharactersCheckBox);
            this.Controls.Add(this.useSpecialCharactersCheckBox);
            this.Controls.Add(this.useAlphabetCheckBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.generatedPasswordTextBox);
            this.Controls.Add(this.generatePasswordButton);
            this.Name = "Form1";
            this.Text = "Password Generator ";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button generatePasswordButton;
        private System.Windows.Forms.RichTextBox generatedPasswordTextBox;
        private System.Windows.Forms.ComboBox previousPasswordscomboBox;
        private System.Windows.Forms.Button copySelectedPreviousPassword;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox useAlphabetCheckBox;
        private System.Windows.Forms.CheckBox useSpecialCharactersCheckBox;
        private System.Windows.Forms.Button saveToFileButton;
        private System.Windows.Forms.Button clearListButton;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox dontRepeatCharactersCheckBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


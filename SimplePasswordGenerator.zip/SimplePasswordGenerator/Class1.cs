﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    class Password
    {
        internal string result { get; set; }
        string backup { get; set; }
        
        Random unitForPassword = new Random();
        string Alphabet = "abcdefghijklmnopqrstuvwxyz";
        string Number = "0123456789";
        string Special = "!#$%&'()*+,-./:;<=>?@[]^_`{|}~";
        public Password(int numberOfCharacters, bool useAlphabet, bool useSpecial, bool dontRepeat)
        {

            if (useAlphabet && useSpecial == true)
            {
                char[] characterVector = (Number + Special + Alphabet + Alphabet.ToUpper()).ToCharArray();

                fillResult(numberOfCharacters, dontRepeat, characterVector);
            }
            else if (useSpecial == true || useAlphabet == true)
            {
                if (useSpecial == true)
                {
                    char[] characterVector = (Number + Special).ToCharArray();

                    fillResult(numberOfCharacters, dontRepeat, characterVector);
                }
                if (useAlphabet == true)
                {
                    char[] characterVector = (Number + Alphabet + Alphabet.ToUpper()).ToCharArray();

                    fillResult(numberOfCharacters, dontRepeat, characterVector);
                }
            }
            else
            {
                char[] characterVector = (Number).ToCharArray();

                fillResult(numberOfCharacters, dontRepeat, characterVector);
            }

        }

        private bool checkForRepeatedCharacters(string samplePassword, char[] localcharacterVector) 
        {
            char[] sampleVector = (samplePassword).ToCharArray();
            int count = 0;
            bool repeated = false;

            foreach (char unit in sampleVector) 
            {
                count = 0;

                for (int x = 0; x < sampleVector.Length; x++) 
                {
                    if (samplePassword[x] == unit)
                    {
                        count++;

                        if (count >= 2) 
                        {
                            repeated = true;
                        }
                    }
                }
            }

            return repeated;
        }


        private void fillResult(int numberOfCharacters, bool dontRepeat, char[] localcharacterVector) 
        {
            for (int x = 0; x < numberOfCharacters; x++)
            {
                if (dontRepeat == true)
                {
                    backup = result;
                    this.result += localcharacterVector[unitForPassword.Next(localcharacterVector.Length - 1)];

                    if (checkForRepeatedCharacters(result, localcharacterVector))
                    {
                        result = backup;
                        x--;
                    }

                }
                else
                {
                    this.result += localcharacterVector[unitForPassword.Next(localcharacterVector.Length - 1)];
                }

            }
        }

    }


}
